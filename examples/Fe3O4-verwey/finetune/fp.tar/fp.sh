#!/bin/bash

if [ -f POSCAR ]; then
    line_count=$(wc -l < POSCAR)
    
    if [ "$line_count" -eq 22 ]; then
        mv INCAR.cubic INCAR
    else
        mv INCAR.monoclinic INCAR
    fi

    source /opt/intel/oneapi/setvars.sh
    mpirun -n 32 vasp_std
    
else
    echo "未找到POSCAR文件"
fi
